/* *****************************************************************************
 *  Name:              Gergo Endresz
 *  Coursera User ID:  0b98e7597a04720d1abd8d83dbdbc35a
 *  Last modified:      February 1, 2021
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello world.");
    }
}
